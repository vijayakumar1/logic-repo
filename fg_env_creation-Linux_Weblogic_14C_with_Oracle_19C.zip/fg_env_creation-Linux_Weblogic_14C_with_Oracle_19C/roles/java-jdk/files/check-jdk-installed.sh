#!/bin/sh

PACKAGE=jdk.?$1

line=$(rpm -qa | egrep $PACKAGE | wc -l)


if [[ $line =~ 0 ]]; then
  echo '{ "found": false , "not_found": true  }'

else
  echo '{ "found": true  , "not_found": false }'

fi
